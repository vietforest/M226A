

/*
nome: pari
desc: filtrare numeri pari e numeri dispari

@author: huynh anh nguyen
@data:17.02.2025
*/

public class Pari{
	public static void main(String[] args){
		
		int[] list = new int[args.length];
		for (int i : Integer.parseInt(args)){
			list[i] = i;
		}
		for (int i : args.length){
			if 
			
		}
	}
}